package com.example;

import com.example.Joke;

public class Hello {
  public static String getMessage() {
    Joke joke = new Joke();
    return joke.getHello();
  }

  public static void main(String[] args) {
    System.out.println(new Joke().getHello());
  }
}
