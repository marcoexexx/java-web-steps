package com.example.user;

public class Joke {
  public String getHello() {
    return "Hello";
  }
}
